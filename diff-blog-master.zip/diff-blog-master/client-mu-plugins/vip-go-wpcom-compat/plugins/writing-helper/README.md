Writing Helper
==============